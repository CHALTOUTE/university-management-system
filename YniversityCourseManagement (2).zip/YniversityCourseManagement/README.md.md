# University Course Management System

### Team Members:
* [Montaser Daoud Salim  25586/2024]

* [Mahamat Issa Hassan   29744/2025]

### Project Description:
A Java-based system to manage university students, instructors, and courses using OOP principles.

### OOP Principles Applied:
1. *Inheritance*: Student and Instructor classes extend the User base class.
2. *Encapsulation*: Used private fields with public getters/setters in the Course class to protect data.
3. *Abstraction*: User is an abstract class defining core properties.
4. *Polymorphism*: The displayMenu() method is overridden in both Student and Instructor to show different options.

### How to Run:
1. Open the project in Eclipse.
2. Run Main.java in the Com.university.core package.

### Usage Scenario:
The system simulates a login session. It creates a student and an instructor, then displays their unique dashboards and lists available courses with their current capacity
GROUP:1
GROUP:1
GROUP:1
GROUP:1
GROUP:1
GROUP:1
GROUP:1
GROUP:1
