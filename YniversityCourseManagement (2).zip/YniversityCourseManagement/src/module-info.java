/**
 * 
 */
/**
 * 
 */
module YniversityCourseManagement {
}