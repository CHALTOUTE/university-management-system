package Com.university.users;

import java.util.ArrayList;
import java.util.List;

// Inheritance: Student inherits from the User class
public class Student extends User {

    private double gpa;
    private List<String> enrolledCourses;

    public Student(String id, String name, String email) {
        // Call the constructor of the parent class (User)
        super(id, name, email, "STUDENT");
        this.gpa = 0.0;
        this.enrolledCourses = new ArrayList<>();
    }

    // Polymorphism: Student-specific implementation of the menu
    @Override
    public void displayMenu() {
        System.out.println("\n--- Student Dashboard ---");
        System.out.println("Welcome Student: " + getName());
        System.out.println("1. View Available Courses");
        System.out.println("2. Enroll in Course");
        System.out.println("3. View My Transcript (GPA: " + gpa + ")");
        System.out.println("4. Logout");
    }

    // Encapsulation: Getter for GPA
    public double getGpa() {
        return gpa;
    }
}