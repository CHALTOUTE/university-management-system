package Com.university.users;

import java.util.ArrayList;
import java.util.List;

// Inheritance: Instructor also inherits from the User class
public class Instructor extends User {

    private List<String> assignedCourses;

    public Instructor(String id, String name, String email) {
        // Call the parent class constructor
        super(id, name, email, "INSTRUCTOR");
        this.assignedCourses = new ArrayList<>();
    }

    // Polymorphism: Instructor-specific menu
    @Override
    public void displayMenu() {
        System.out.println("\n--- Instructor Dashboard ---");
        System.out.println("Welcome Prof: " + getName());
        System.out.println("1. View My Assigned Courses");
        System.out.println("2. Grade Students");
        System.out.println("3. Manage Course Content");
        System.out.println("4. Logout");
    }
}
