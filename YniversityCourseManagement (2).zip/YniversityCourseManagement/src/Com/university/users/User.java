package Com.university.users;

/**
 * Abstraction: This is an abstract class that represents the general structure
 * of all users in the system.
 */
public abstract class User {

    // Encapsulation: private variables to protect data
    private String id;
    private String name;
    private String email;
    private String role;

    public User(String id, String name, String email, String role) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.role = role;
    }

    // Getters: allow safe access to data
    public String getName() { return name; }
    public String getId() { return id; }
    public String getRole() { return role; }

    /**
     * Polymorphism: Each subclass (Student, Instructor, Admin)
     * will implement this method differently.
     */
    public abstract void displayMenu();
}