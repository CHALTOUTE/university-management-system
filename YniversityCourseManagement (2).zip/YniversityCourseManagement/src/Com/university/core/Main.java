package Com.university.core;

import Com.university.users.Student;
import Com.university.users.Instructor; // Import Instructor
import Com.university.courses.Course;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== University Management System ===\n");

        // 1. Test the Student dashboard
        Student student = new Student("S101", "Ahmed Ali", "ahmed@university.edu");
        System.out.println(">>> Testing Student View:");
        student.displayMenu();

        // 2. Test the Instructor dashboard (new part)
        Instructor professor = new Instructor("T505", "Dr. Sarah", "sarah@university.edu");
        System.out.println("\n>>> Testing Instructor View:");
        professor.displayMenu();

        // 3. Display available courses in the system
        System.out.println("\n--- Global Course List ---");
        Course javaCourse = new Course("CS101", "Java Programming", 30);
        javaCourse.displayCourseInfo();
    }
}
